function MainPage() {
  return (
    <>
      <p>A Twitter Clone</p>
      <footer>
        Copyright &copy; 2022 MERN Twitter
      </footer>
    </>
  );
}

export default MainPage;
